import React from 'react';
import {
  Building2,
  AlertTriangle,
  Zap,
  Sparkles,
  History,
  Plus,
  BarChart3,
  Calendar,
  Layers,
} from 'lucide-react';

interface HeaderProps {
  activeTab: 'overview' | 'schedule' | 'conflicts' | 'resources';
  setActiveTab: (tab: 'overview' | 'schedule' | 'conflicts' | 'resources') => void;
  criticalConflictCount: number;
  warningsCount: number;
  onOpenNewAllocation: () => void;
  onOpenEmergencySimulator: () => void;
  onOpenAIAssistant: () => void;
  onOpenHistory: () => void;
  onAutoResolveAll: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  criticalConflictCount,
  warningsCount,
  onOpenNewAllocation,
  onOpenEmergencySimulator,
  onOpenAIAssistant,
  onOpenHistory,
  onAutoResolveAll,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-slate-900 text-white border-b border-slate-800 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main top bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between py-3 gap-3">
          {/* Logo & Title */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-blue-500 flex items-center justify-center shadow-inner text-white">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-lg font-bold tracking-tight text-white flex items-center gap-2">
                  Smart Campus Resource Assistant
                </h1>
                <span className="hidden md:inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-indigo-950 text-indigo-300 border border-indigo-700/60">
                  EduResource OS v2.4
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Automated classroom, lab, faculty & equipment allocation engine
              </p>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center flex-wrap gap-2">
            {/* Last-minute simulator trigger */}
            <button
              onClick={onOpenEmergencySimulator}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-amber-500/15 text-amber-300 border border-amber-500/30 hover:bg-amber-500/25 transition-colors cursor-pointer"
              title="Test last-minute emergencies like room maintenance, faculty absence or capacity surge"
            >
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>Simulate Emergency</span>
            </button>

            {/* AI Assistant */}
            <button
              onClick={onOpenAIAssistant}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-purple-500/15 text-purple-300 border border-purple-500/30 hover:bg-purple-500/25 transition-colors cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              <span>AI Advisor</span>
            </button>

            {/* Reallocation History */}
            <button
              onClick={onOpenHistory}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 text-slate-300 border border-slate-700 hover:bg-slate-700 transition-colors cursor-pointer"
              title="View audit log of reallocations"
            >
              <History className="w-3.5 h-3.5 text-slate-400" />
              <span className="hidden sm:inline">Audit Log</span>
            </button>

            {/* Auto-Resolve button if conflicts exist */}
            {criticalConflictCount > 0 && (
              <button
                onClick={onAutoResolveAll}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white shadow transition-all cursor-pointer animate-pulse"
                title="Automatically reallocate all conflicting sessions to best available rooms without cascade clashes"
              >
                <Zap className="w-3.5 h-3.5" />
                <span>Auto-Resolve All ({criticalConflictCount})</span>
              </button>
            )}

            {/* New Allocation */}
            <button
              onClick={onOpenNewAllocation}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white shadow transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>New Allocation</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center space-x-1 sm:space-x-2 border-t border-slate-800 pt-2 pb-1 overflow-x-auto text-sm">
          <button
            onClick={() => setActiveTab('overview')}
            className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-md font-medium text-xs transition-colors cursor-pointer ${
              activeTab === 'overview'
                ? 'bg-indigo-600/30 text-indigo-300 border border-indigo-500/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span>Dashboard Overview</span>
          </button>

          <button
            onClick={() => setActiveTab('schedule')}
            className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-md font-medium text-xs transition-colors cursor-pointer ${
              activeTab === 'schedule'
                ? 'bg-indigo-600/30 text-indigo-300 border border-indigo-500/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span>Timetable & Grid</span>
          </button>

          <button
            onClick={() => setActiveTab('conflicts')}
            className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-md font-medium text-xs transition-colors cursor-pointer relative ${
              activeTab === 'conflicts'
                ? 'bg-rose-600/30 text-rose-300 border border-rose-500/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <AlertTriangle className="w-4 h-4 text-rose-400" />
            <span>Conflict Workbench</span>
            {criticalConflictCount > 0 && (
              <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-rose-500 text-white">
                {criticalConflictCount}
              </span>
            )}
            {criticalConflictCount === 0 && warningsCount > 0 && (
              <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-amber-500 text-slate-900">
                {warningsCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('resources')}
            className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-md font-medium text-xs transition-colors cursor-pointer ${
              activeTab === 'resources'
                ? 'bg-indigo-600/30 text-indigo-300 border border-indigo-500/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Resource Directory</span>
          </button>
        </div>
      </div>
    </header>
  );
};
