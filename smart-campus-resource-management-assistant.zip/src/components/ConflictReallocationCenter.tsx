import React, { useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  Building,
  Users,
  Cpu,
  Layers,
  Check,
  Zap,
  Info,
  ChevronRight,
} from 'lucide-react';
import { Conflict, Allocation, Room, Faculty } from '../types';

interface ConflictReallocationCenterProps {
  conflicts: Conflict[];
  allocations: Allocation[];
  rooms: Room[];
  facultyList: Faculty[];
  onApplyAlternative: (allocationId: string, targetRoomId: string, reason: string) => void;
  onAutoResolveAll: () => void;
  onOpenNewAllocation: () => void;
}

export const ConflictReallocationCenter: React.FC<ConflictReallocationCenterProps> = ({
  conflicts,
  allocations,
  rooms,
  facultyList,
  onApplyAlternative,
  onAutoResolveAll,
}) => {
  const [selectedConflictId, setSelectedConflictId] = useState<string | null>(
    conflicts.length > 0 ? conflicts[0].id : null
  );

  // If selected conflict was resolved, pick the next one
  const currentConflict = conflicts.find((c) => c.id === selectedConflictId) || (conflicts.length > 0 ? conflicts[0] : null);

  const getTargetAllocation = (allocId: string) => allocations.find((a) => a.id === allocId);
  const getRoom = (roomId: string) => rooms.find((r) => r.id === roomId);
  const getFaculty = (facultyId: string) => facultyList.find((f) => f.id === facultyId);

  if (conflicts.length === 0) {
    return (
      <div className="bg-white rounded-xl border border-slate-200/80 p-8 text-center shadow-xs">
        <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-4">
          <CheckCircle2 className="w-8 h-8" />
        </div>
        <h3 className="text-lg font-bold text-slate-900 mb-1">
          Zero Conflicts Detected Across Campus
        </h3>
        <p className="text-sm text-slate-500 max-w-md mx-auto mb-6">
          Every classroom, computer lab, science facility, and instructor schedule is completely valid with no overlapping bookings, capacity shortages, or equipment deficits.
        </p>
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-600">
          <Info className="w-3.5 h-3.5 text-indigo-500" />
          <span>Tip: You can use the "Simulate Emergency" button to test last-minute breakdown handling.</span>
        </div>
      </div>
    );
  }

  const activeAllocation = currentConflict ? getTargetAllocation(currentConflict.allocationId) : null;
  const currentRoom = activeAllocation ? getRoom(activeAllocation.assignedRoomId) : null;
  const currentFaculty = activeAllocation ? getFaculty(activeAllocation.assignedFacultyId) : null;

  return (
    <div className="space-y-4">
      {/* Top Banner with Auto-Resolve Action */}
      <div className="bg-slate-900 text-white rounded-xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm border border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-xs font-bold bg-rose-500 text-white">
              {conflicts.length} Active Issue{conflicts.length === 1 ? '' : 's'}
            </span>
            <h2 className="text-base font-bold text-white">
              Smart Conflict Resolution & Reallocation Workbench
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            The automated constraint solver evaluates capacity limits, installed PC workstations, faculty commitments, and room availability to provide optimal zero-clash alternatives.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-shrink-0">
          <button
            onClick={onAutoResolveAll}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white shadow-md transition-all cursor-pointer"
          >
            <Zap className="w-4 h-4" />
            <span>Auto-Resolve All ({conflicts.length})</span>
          </button>
        </div>
      </div>

      {/* Main 2-column layout: Conflicts list on left, deep resolution workbench on right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: Conflict Selector */}
        <div className="lg:col-span-5 space-y-2">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-500 px-1">
            Detected Scheduling Conflicts
          </div>

          <div className="space-y-2">
            {conflicts.map((conflict) => {
              const alloc = getTargetAllocation(conflict.allocationId);
              const isSelected = currentConflict?.id === conflict.id;

              return (
                <div
                  key={conflict.id}
                  onClick={() => setSelectedConflictId(conflict.id)}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer text-left relative ${
                    isSelected
                      ? 'bg-rose-50/90 border-rose-400 shadow-sm ring-1 ring-rose-300'
                      : 'bg-white border-slate-200 hover:border-slate-300 shadow-xs'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-1.5">
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] font-bold uppercase ${
                          conflict.severity === 'critical'
                            ? 'bg-rose-600 text-white'
                            : 'bg-amber-500 text-slate-900'
                        }`}
                      >
                        {conflict.type.replace('_', ' ')}
                      </span>
                      <span className="text-[11px] font-semibold text-slate-500">
                        {alloc?.day} {alloc?.timeSlot}
                      </span>
                    </div>

                    {conflict.alternatives && conflict.alternatives.length > 0 && (
                      <span className="text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded font-medium">
                        {conflict.alternatives.length} alternatives
                      </span>
                    )}
                  </div>

                  <h4 className="text-xs font-bold text-slate-900 mt-1.5">
                    {conflict.title}
                  </h4>
                  <p className="text-[11px] text-slate-600 line-clamp-2 mt-0.5">
                    {conflict.description}
                  </p>

                  <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                    <span className="font-medium text-slate-700 truncate max-w-[180px]">
                      {alloc?.courseTitle}
                    </span>
                    <span className="text-indigo-600 flex items-center gap-0.5 font-semibold">
                      Inspect <ChevronRight className="w-3 h-3" />
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Alternative Solver & Comparison */}
        <div className="lg:col-span-7">
          {currentConflict && activeAllocation ? (
            <div className="bg-white rounded-xl border border-slate-200/80 p-5 shadow-xs space-y-4">
              {/* Conflict Header */}
              <div className="pb-3 border-b border-slate-200">
                <div className="flex items-center gap-2 text-xs text-rose-700 font-semibold mb-1">
                  <AlertTriangle className="w-4 h-4" />
                  <span>Conflict Analysis & Resolution Details</span>
                </div>
                <h3 className="text-base font-bold text-slate-900">
                  {currentConflict.title}
                </h3>
                <p className="text-xs text-slate-600 mt-1">
                  {currentConflict.description}
                </p>
              </div>

              {/* Current Troubled Booking Snapshot */}
              <div className="bg-slate-50 rounded-lg p-3 border border-slate-200/80 text-xs">
                <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2">
                  Current Problematic Assignment
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Course</span>
                    <span className="font-bold text-slate-800">{activeAllocation.courseTitle}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Students Enrolled</span>
                    <span className="font-bold text-slate-800">{activeAllocation.studentStrength} Students</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Current Venue</span>
                    <span className="font-bold text-rose-700">
                      {currentRoom?.name} (Cap: {currentRoom?.capacity})
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Assigned Faculty</span>
                    <span className="font-bold text-slate-800">{currentFaculty?.name}</span>
                  </div>
                </div>
              </div>

              {/* Alternative Recommendations */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-700">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Ranked Reallocation Options</span>
                  </div>
                  <span className="text-xs text-slate-500">
                    Sorted by suitability & zero-overlap score
                  </span>
                </div>

                {currentConflict.alternatives && currentConflict.alternatives.length > 0 ? (
                  <div className="space-y-2.5">
                    {currentConflict.alternatives.map((alt, idx) => (
                      <div
                        key={alt.roomId}
                        className={`p-4 rounded-xl border transition-all ${
                          alt.isRecommended
                            ? 'bg-emerald-50/60 border-emerald-300 ring-1 ring-emerald-200'
                            : 'bg-white border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                          <div>
                            <div className="flex items-center gap-2">
                              {alt.isRecommended && (
                                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-600 text-white uppercase tracking-wider">
                                  Top Recommendation
                                </span>
                              )}
                              <h4 className="text-sm font-bold text-slate-900">
                                {alt.roomName}
                              </h4>
                              <span className="text-xs font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                                {alt.matchScore}% Match
                              </span>
                            </div>

                            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-600 mt-1">
                              <span className="flex items-center gap-1 font-medium text-slate-700">
                                <Users className="w-3.5 h-3.5 text-slate-400" />
                                Capacity: {alt.capacity} seats (+{alt.capacityHeadroom} buffer)
                              </span>
                              {alt.availableComputers > 0 && (
                                <span className="flex items-center gap-1 font-medium text-blue-700">
                                  <Cpu className="w-3.5 h-3.5 text-blue-500" />
                                  {alt.availableComputers} Working PCs
                                </span>
                              )}
                              <span className="flex items-center gap-1 text-slate-500">
                                <Building className="w-3.5 h-3.5 text-slate-400" />
                                {alt.building}
                              </span>
                            </div>
                          </div>

                          <button
                            onClick={() =>
                              onApplyAlternative(
                                activeAllocation.id,
                                alt.roomId,
                                `Reallocated from ${currentRoom?.name || 'troubled venue'} to ${alt.roomName} via Conflict Resolution Workbench.`
                              )
                            }
                            className={`inline-flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex-shrink-0 ${
                              alt.isRecommended
                                ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-xs'
                                : 'bg-slate-900 hover:bg-slate-800 text-white'
                            }`}
                          >
                            <span>Apply Reallocation</span>
                            <ArrowRight className="w-3 h-3" />
                          </button>
                        </div>

                        {/* Pros and Cons */}
                        <div className="mt-2.5 pt-2 border-t border-slate-200/60 text-xs space-y-1">
                          {alt.pros.map((pro, pIdx) => (
                            <div key={pIdx} className="text-emerald-800 flex items-center gap-1 text-[11px]">
                              <Check className="w-3 h-3 text-emerald-600 flex-shrink-0" />
                              <span>{pro}</span>
                            </div>
                          ))}
                          {alt.cons &&
                            alt.cons.map((con, cIdx) => (
                              <div key={cIdx} className="text-amber-800 flex items-center gap-1 text-[11px]">
                                <Info className="w-3 h-3 text-amber-500 flex-shrink-0" />
                                <span>{con}</span>
                              </div>
                            ))}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-4 bg-amber-50 rounded-lg border border-amber-200 text-amber-900 text-xs">
                    <p className="font-semibold">No direct room alternatives currently vacant in this timeslot.</p>
                    <p className="mt-1 text-slate-600">
                      Recommendation: Consider shifting this class to a different time slot or splitting into two lab batches.
                    </p>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-xl border border-slate-200/80 p-8 text-center text-slate-500">
              Select a conflict from the left panel to inspect alternatives.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
