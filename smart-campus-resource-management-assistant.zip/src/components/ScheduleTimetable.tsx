import React, { useState } from 'react';
import {
  Calendar as CalendarIcon,
  Clock,
  MapPin,
  User,
  AlertTriangle,
  CheckCircle2,
  Filter,
  ArrowRightLeft,
  Sparkles,
  Edit2,
  Cpu,
  Plus,
} from 'lucide-react';
import {
  Allocation,
  Room,
  Faculty,
  Conflict,
  DayOfWeek,
  ActivityType,
} from '../types';
import { DAYS_OF_WEEK, TIME_SLOTS } from '../data/initialData';

interface ScheduleTimetableProps {
  allocations: Allocation[];
  rooms: Room[];
  facultyList: Faculty[];
  conflicts: Conflict[];
  onSelectAllocation: (allocation: Allocation) => void;
  onEditAllocation: (allocation: Allocation) => void;
  onNewAllocationForSlot?: (day: DayOfWeek, slot: string) => void;
  onResolveConflictForAllocation: (allocation: Allocation) => void;
}

export const ScheduleTimetable: React.FC<ScheduleTimetableProps> = ({
  allocations,
  rooms,
  facultyList,
  conflicts,
  onSelectAllocation,
  onEditAllocation,
  onNewAllocationForSlot,
  onResolveConflictForAllocation,
}) => {
  const [selectedDay, setSelectedDay] = useState<DayOfWeek | 'all'>('all');
  const [selectedActivity, setSelectedActivity] = useState<ActivityType | 'all'>('all');
  const [selectedRoomFilter, setSelectedRoomFilter] = useState<string>('all');
  const [showConflictsOnly, setShowConflictsOnly] = useState<boolean>(false);

  // Filter allocations
  const filteredAllocations = allocations.filter((alloc) => {
    if (selectedDay !== 'all' && alloc.day !== selectedDay) return false;
    if (selectedActivity !== 'all' && alloc.activityType !== selectedActivity) return false;
    if (selectedRoomFilter !== 'all' && alloc.assignedRoomId !== selectedRoomFilter) return false;
    if (showConflictsOnly) {
      const hasConflict = conflicts.some((c) => c.allocationId === alloc.id);
      if (!hasConflict) return false;
    }
    return true;
  });

  const getConflictForAllocation = (allocId: string) => {
    return conflicts.find((c) => c.allocationId === allocId);
  };

  const getRoom = (roomId: string) => rooms.find((r) => r.id === roomId);
  const getFaculty = (facultyId: string) => facultyList.find((f) => f.id === facultyId);

  const daysToDisplay: DayOfWeek[] = selectedDay === 'all' ? [...DAYS_OF_WEEK] : [selectedDay];

  return (
    <div className="bg-white rounded-xl border border-slate-200/80 shadow-xs overflow-hidden">
      {/* Filter toolbar */}
      <div className="p-4 border-b border-slate-200/80 bg-slate-50/50 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-2">
          <CalendarIcon className="w-5 h-5 text-indigo-600" />
          <h2 className="text-base font-bold text-slate-900">
            Campus Timetable & Schedule Grid
          </h2>
          <span className="text-xs text-slate-500">
            ({filteredAllocations.length} sessions displayed)
          </span>
        </div>

        {/* Filter Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Day Selector Buttons */}
          <div className="inline-flex rounded-lg border border-slate-200 bg-white p-0.5 text-xs shadow-xs">
            <button
              onClick={() => setSelectedDay('all')}
              className={`px-2.5 py-1 rounded-md font-medium transition-colors cursor-pointer ${
                selectedDay === 'all'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Days
            </button>
            {DAYS_OF_WEEK.map((day) => (
              <button
                key={day}
                onClick={() => setSelectedDay(day)}
                className={`px-2.5 py-1 rounded-md font-medium transition-colors cursor-pointer ${
                  selectedDay === day
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {day.slice(0, 3)}
              </button>
            ))}
          </div>

          {/* Activity Filter */}
          <select
            value={selectedActivity}
            onChange={(e) => setSelectedActivity(e.target.value as any)}
            className="text-xs border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white text-slate-700 shadow-xs focus:ring-2 focus:ring-indigo-500 focus:outline-hidden cursor-pointer"
          >
            <option value="all">All Activities</option>
            <option value="lab_practical">Laboratory Practical</option>
            <option value="lecture">Theory Lecture</option>
            <option value="seminar">Seminar / Defense</option>
          </select>

          {/* Room Filter */}
          <select
            value={selectedRoomFilter}
            onChange={(e) => setSelectedRoomFilter(e.target.value)}
            className="text-xs border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white text-slate-700 shadow-xs focus:ring-2 focus:ring-indigo-500 focus:outline-hidden cursor-pointer max-w-[150px] truncate"
          >
            <option value="all">All Rooms & Labs</option>
            {rooms.map((r) => (
              <option key={r.id} value={r.id}>
                {r.code} ({r.capacity} seats)
              </option>
            ))}
          </select>

          {/* Conflicts Only Toggle */}
          <button
            onClick={() => setShowConflictsOnly(!showConflictsOnly)}
            className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold border transition-colors cursor-pointer ${
              showConflictsOnly
                ? 'bg-rose-100 text-rose-800 border-rose-300'
                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
            }`}
          >
            <AlertTriangle className={`w-3.5 h-3.5 ${showConflictsOnly ? 'text-rose-600' : 'text-slate-400'}`} />
            <span>Conflicts Only</span>
          </button>
        </div>
      </div>

      {/* Timetable Grid */}
      <div className="p-4 space-y-6">
        {daysToDisplay.map((day) => {
          const dayAllocations = filteredAllocations.filter((a) => a.day === day);

          return (
            <div key={day} className="space-y-2">
              <div className="flex items-center justify-between pb-1 border-b border-slate-200">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-indigo-600" />
                  {day}
                </span>
                <span className="text-xs text-slate-400">
                  {dayAllocations.length} class{dayAllocations.length === 1 ? '' : 'es'} scheduled
                </span>
              </div>

              {/* Time slot columns */}
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-3">
                {TIME_SLOTS.map((slot) => {
                  const slotAllocations = dayAllocations.filter((a) => a.timeSlot === slot);

                  return (
                    <div
                      key={`${day}-${slot}`}
                      className="rounded-lg border border-slate-200/90 bg-slate-50/40 p-2.5 flex flex-col min-h-[140px]"
                    >
                      {/* Slot Header */}
                      <div className="flex items-center justify-between text-[11px] font-semibold text-slate-500 pb-2 border-b border-slate-200/60 mb-2">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3 text-slate-400" />
                          {slot}
                        </span>
                        {slotAllocations.length === 0 && (
                          <span className="text-[10px] text-slate-400 font-normal">Available</span>
                        )}
                      </div>

                      {/* Allocations in this slot */}
                      <div className="space-y-2 flex-1">
                        {slotAllocations.length > 0 ? (
                          slotAllocations.map((alloc) => {
                            const conflict = getConflictForAllocation(alloc.id);
                            const room = getRoom(alloc.assignedRoomId);
                            const faculty = getFaculty(alloc.assignedFacultyId);
                            const isCapacityMismatch = room && alloc.studentStrength > room.capacity;

                            return (
                              <div
                                key={alloc.id}
                                className={`p-3 rounded-lg border transition-all text-xs relative group ${
                                  conflict
                                    ? 'bg-rose-50 border-rose-300 shadow-xs'
                                    : alloc.status === 'reallocated'
                                    ? 'bg-emerald-50/70 border-emerald-200 shadow-xs'
                                    : 'bg-white border-slate-200 hover:border-indigo-300 shadow-xs'
                                }`}
                              >
                                {/* Activity and Status Badges */}
                                <div className="flex items-center justify-between gap-1 mb-1.5">
                                  <span
                                    className={`px-1.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                                      alloc.activityType === 'lab_practical'
                                        ? 'bg-emerald-100 text-emerald-800'
                                        : alloc.activityType === 'lecture'
                                        ? 'bg-blue-100 text-blue-800'
                                        : 'bg-amber-100 text-amber-800'
                                    }`}
                                  >
                                    {alloc.activityType === 'lab_practical'
                                      ? 'Lab'
                                      : alloc.activityType === 'lecture'
                                      ? 'Lecture'
                                      : 'Seminar'}
                                  </span>

                                  {conflict ? (
                                    <span className="inline-flex items-center gap-1 text-[10px] font-bold text-rose-700 bg-rose-100 px-1.5 py-0.5 rounded">
                                      <AlertTriangle className="w-3 h-3" />
                                      Clash
                                    </span>
                                  ) : alloc.status === 'reallocated' ? (
                                    <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded">
                                      <CheckCircle2 className="w-3 h-3" />
                                      Reallocated
                                    </span>
                                  ) : (
                                    <span className="text-[10px] font-medium text-slate-400">
                                      {alloc.courseCode}
                                    </span>
                                  )}
                                </div>

                                {/* Course Title */}
                                <h4 className="font-bold text-slate-900 line-clamp-1 mb-1.5" title={alloc.courseTitle}>
                                  {alloc.courseTitle}
                                </h4>

                                {/* Venue and Capacity */}
                                <div className="space-y-1 text-slate-600 text-[11px]">
                                  <div className="flex items-center justify-between">
                                    <span className="flex items-center gap-1 text-slate-700 font-medium truncate max-w-[130px]">
                                      <MapPin className="w-3 h-3 text-slate-400 flex-shrink-0" />
                                      {room?.name || 'Unassigned'}
                                    </span>

                                    {/* Capacity Badge */}
                                    {room && (
                                      <span
                                        className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                                          isCapacityMismatch
                                            ? 'bg-rose-600 text-white'
                                            : 'bg-slate-100 text-slate-700'
                                        }`}
                                        title={`Enrolled: ${alloc.studentStrength} students / Room Capacity: ${room.capacity}`}
                                      >
                                        {alloc.studentStrength}/{room.capacity}
                                      </span>
                                    )}
                                  </div>

                                  {/* Faculty */}
                                  <div className="flex items-center gap-1 text-slate-500">
                                    <User className="w-3 h-3 text-slate-400 flex-shrink-0" />
                                    <span className="truncate">{faculty?.name || 'Unassigned'}</span>
                                  </div>

                                  {/* Equipment requirement tag */}
                                  {alloc.requiredEquipment.length > 0 && (
                                    <div className="flex items-center gap-1 text-slate-500 text-[10px] pt-0.5">
                                      <Cpu className="w-3 h-3 text-slate-400 flex-shrink-0" />
                                      <span>
                                        {alloc.requiredEquipment.map((eq) => `${eq.minQuantity} ${eq.name}`).join(', ')}
                                      </span>
                                    </div>
                                  )}
                                </div>

                                {/* Action Buttons */}
                                <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between">
                                  {conflict ? (
                                    <button
                                      onClick={() => onResolveConflictForAllocation(alloc)}
                                      className="inline-flex items-center gap-1 text-[11px] font-bold text-rose-700 hover:text-rose-900 bg-rose-100/80 hover:bg-rose-200/80 px-2 py-0.5 rounded transition-colors cursor-pointer"
                                    >
                                      <Sparkles className="w-3 h-3" />
                                      <span>Resolve Clash</span>
                                    </button>
                                  ) : (
                                    <button
                                      onClick={() => onEditAllocation(alloc)}
                                      className="inline-flex items-center gap-1 text-[10px] font-medium text-slate-500 hover:text-indigo-600 transition-colors cursor-pointer"
                                    >
                                      <Edit2 className="w-2.5 h-2.5" />
                                      <span>Modify</span>
                                    </button>
                                  )}

                                  <button
                                    onClick={() => onSelectAllocation(alloc)}
                                    className="text-[10px] text-indigo-600 hover:underline cursor-pointer"
                                  >
                                    Details
                                  </button>
                                </div>
                              </div>
                            );
                          })
                        ) : (
                          <div className="h-full flex flex-col items-center justify-center text-center p-2 text-slate-400 text-xs">
                            <span className="text-[11px]">Free Slot</span>
                            {onNewAllocationForSlot && (
                              <button
                                onClick={() => onNewAllocationForSlot(day, slot)}
                                className="mt-1 inline-flex items-center gap-1 text-[10px] text-indigo-600 hover:text-indigo-800 font-medium cursor-pointer"
                              >
                                <Plus className="w-3 h-3" />
                                Book
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
