import React, { useState, useEffect, useMemo } from 'react';
import { Header } from './components/Header';
import { MetricCards } from './components/MetricCards';
import { ConflictAlertBanner } from './components/ConflictAlertBanner';
import { ScheduleTimetable } from './components/ScheduleTimetable';
import { ConflictReallocationCenter } from './components/ConflictReallocationCenter';
import { ResourceDirectory } from './components/ResourceDirectory';
import { EmergencySimulatorModal } from './components/EmergencySimulatorModal';
import { AllocationModal } from './components/AllocationModal';
import { ReallocationHistoryModal } from './components/ReallocationHistoryModal';
import { AIAssistantDrawer } from './components/AIAssistantDrawer';

import {
  Allocation,
  Room,
  Faculty,
  EquipmentItem,
  ReallocationLog,
  RoomStatus,
  FacultyStatus,
  DayOfWeek,
} from './types';

import {
  INITIAL_ROOMS,
  INITIAL_FACULTY,
  INITIAL_EQUIPMENT,
  INITIAL_ALLOCATIONS,
} from './data/initialData';

import {
  validateAllAllocations,
  calculateCampusMetrics,
  findAlternativesForAllocation,
} from './utils/conflictEngine';

import { CheckCircle2, AlertTriangle, Info, Zap, Sparkles } from 'lucide-react';

export default function App() {
  // --- Persistent State ---
  const [rooms, setRooms] = useState<Room[]>(() => {
    const saved = localStorage.getItem('smart_campus_rooms');
    return saved ? JSON.parse(saved) : INITIAL_ROOMS;
  });

  const [facultyList, setFacultyList] = useState<Faculty[]>(() => {
    const saved = localStorage.getItem('smart_campus_faculty');
    return saved ? JSON.parse(saved) : INITIAL_FACULTY;
  });

  const [equipmentList, setEquipmentList] = useState<EquipmentItem[]>(() => {
    const saved = localStorage.getItem('smart_campus_equipment');
    return saved ? JSON.parse(saved) : INITIAL_EQUIPMENT;
  });

  const [allocations, setAllocations] = useState<Allocation[]>(() => {
    const saved = localStorage.getItem('smart_campus_allocations');
    return saved ? JSON.parse(saved) : INITIAL_ALLOCATIONS;
  });

  const [reallocationLogs, setReallocationLogs] = useState<ReallocationLog[]>(() => {
    const saved = localStorage.getItem('smart_campus_logs');
    return saved ? JSON.parse(saved) : [];
  });

  // Save to localStorage on change
  useEffect(() => {
    localStorage.setItem('smart_campus_rooms', JSON.stringify(rooms));
  }, [rooms]);

  useEffect(() => {
    localStorage.setItem('smart_campus_faculty', JSON.stringify(facultyList));
  }, [facultyList]);

  useEffect(() => {
    localStorage.setItem('smart_campus_equipment', JSON.stringify(equipmentList));
  }, [equipmentList]);

  useEffect(() => {
    localStorage.setItem('smart_campus_allocations', JSON.stringify(allocations));
  }, [allocations]);

  useEffect(() => {
    localStorage.setItem('smart_campus_logs', JSON.stringify(reallocationLogs));
  }, [reallocationLogs]);

  // --- Active Navigation Tab ---
  const [activeTab, setActiveTab] = useState<'overview' | 'schedule' | 'conflicts' | 'resources'>('overview');

  // --- Modals State ---
  const [isAllocationModalOpen, setIsAllocationModalOpen] = useState(false);
  const [allocationToEdit, setAllocationToEdit] = useState<Allocation | null>(null);
  const [initialSlotForNew, setInitialSlotForNew] = useState<{ day: DayOfWeek; slot: string } | null>(null);

  const [isEmergencyModalOpen, setIsEmergencyModalOpen] = useState(false);
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);
  const [isAIDrawerOpen, setIsAIDrawerOpen] = useState(false);

  // --- Toast Notification Banner ---
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'info' | 'warning' } | null>(null);

  const showToast = (text: string, type: 'success' | 'info' | 'warning' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => {
      setToastMessage(null);
    }, 4500);
  };

  // --- Real-time Conflict Engine Evaluation ---
  const activeConflicts = useMemo(() => {
    return validateAllAllocations(allocations, rooms, facultyList, equipmentList);
  }, [allocations, rooms, facultyList, equipmentList]);

  // --- Campus Metrics ---
  const campusMetrics = useMemo(() => {
    return calculateCampusMetrics(allocations, rooms, facultyList, activeConflicts);
  }, [allocations, rooms, facultyList, activeConflicts]);

  // --- Reallocation Action ---
  const handleApplyAlternative = (allocationId: string, targetRoomId: string, reason: string) => {
    const targetAlloc = allocations.find((a) => a.id === allocationId);
    const prevRoom = rooms.find((r) => r.id === targetAlloc?.assignedRoomId);
    const newRoom = rooms.find((r) => r.id === targetRoomId);

    if (!targetAlloc || !newRoom) return;

    // Apply update to allocations
    setAllocations((prev) =>
      prev.map((a) => {
        if (a.id === allocationId) {
          return {
            ...a,
            assignedRoomId: targetRoomId,
            status: 'reallocated',
            notes: reason,
          };
        }
        return a;
      })
    );

    // Record audit log
    const newLog: ReallocationLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      allocationId,
      courseCode: targetAlloc.courseCode,
      courseTitle: targetAlloc.courseTitle,
      reason,
      previousRoomId: prevRoom?.id || '',
      previousRoomName: prevRoom?.name || 'Previous Room',
      newRoomId: newRoom.id,
      newRoomName: newRoom.name,
    };

    setReallocationLogs((prev) => [newLog, ...prev]);

    showToast(
      `Reallocated ${targetAlloc.courseTitle} to ${newRoom.name}. Capacity & equipment constraints satisfied!`,
      'success'
    );
  };

  // --- Batch Auto-Resolve All Conflicts ---
  const handleAutoResolveAll = () => {
    if (activeConflicts.length === 0) return;

    let updatedAllocations = [...allocations];
    const newLogs: ReallocationLog[] = [];
    let resolvedCount = 0;

    for (const conflict of activeConflicts) {
      if (conflict.severity === 'critical') {
        const alloc = updatedAllocations.find((a) => a.id === conflict.allocationId);
        if (!alloc) continue;

        // Find alternatives with current working snapshot
        const alternatives = findAlternativesForAllocation(alloc, updatedAllocations, rooms);
        if (alternatives.length > 0) {
          const bestAlt = alternatives[0];
          const prevRoom = rooms.find((r) => r.id === alloc.assignedRoomId);
          const newRoom = rooms.find((r) => r.id === bestAlt.roomId);

          if (newRoom) {
            updatedAllocations = updatedAllocations.map((a) =>
              a.id === alloc.id
                ? {
                    ...a,
                    assignedRoomId: newRoom.id,
                    status: 'reallocated',
                    notes: `Auto-resolved conflict: Reallocated to ${newRoom.name} (${bestAlt.matchScore}% Match)`,
                  }
                : a
            );

            newLogs.push({
              id: `log-${Date.now()}-${resolvedCount}`,
              timestamp: new Date().toISOString(),
              allocationId: alloc.id,
              courseCode: alloc.courseCode,
              courseTitle: alloc.courseTitle,
              reason: `Automated Reallocation: Shifted to ${newRoom.name} to eliminate ${conflict.title}`,
              previousRoomId: prevRoom?.id || '',
              previousRoomName: prevRoom?.name || 'Previous Room',
              newRoomId: newRoom.id,
              newRoomName: newRoom.name,
            });

            resolvedCount++;
          }
        }
      }
    }

    setAllocations(updatedAllocations);
    setReallocationLogs((prev) => [...newLogs, ...prev]);

    showToast(
      `System systematically reallocated ${resolvedCount} conflicting session${
        resolvedCount === 1 ? '' : 's'
      } with zero cascade clashes!`,
      'success'
    );
  };

  // --- Room and Faculty Status Handlers ---
  const handleUpdateRoomStatus = (roomId: string, newStatus: RoomStatus, reason?: string) => {
    setRooms((prev) =>
      prev.map((r) => (r.id === roomId ? { ...r, status: newStatus, statusReason: reason } : r))
    );

    const room = rooms.find((r) => r.id === roomId);
    if (newStatus === 'maintenance') {
      showToast(`Facility ${room?.code || roomId} marked for maintenance. Checking affected sessions...`, 'warning');
    } else {
      showToast(`Facility ${room?.code || roomId} restored to Available status.`, 'success');
    }
  };

  const handleUpdateFacultyStatus = (facultyId: string, newStatus: FacultyStatus, reason?: string) => {
    setFacultyList((prev) =>
      prev.map((f) => (f.id === facultyId ? { ...f, status: newStatus, statusReason: reason } : f))
    );

    const fac = facultyList.find((f) => f.id === facultyId);
    if (newStatus !== 'active') {
      showToast(`Instructor ${fac?.name || facultyId} marked as ${newStatus.replace('_', ' ')}.`, 'warning');
    } else {
      showToast(`Instructor ${fac?.name || facultyId} is now Active.`, 'success');
    }
  };

  // --- Emergency Simulation Presets ---
  const handleTriggerPromptSampleScenario = () => {
    // Reset room statuses
    setRooms(INITIAL_ROOMS);
    setFacultyList(INITIAL_FACULTY);

    // Set Data Structures with 65 students in Lab 204 (capacity 60)
    setAllocations((prev) => {
      const existing = prev.filter((a) => a.id !== 'alloc-ds-lab-sample');
      return [
        {
          id: 'alloc-ds-lab-sample',
          courseCode: 'CS201',
          courseTitle: 'Data Structures Lab (Core CS)',
          activityType: 'lab_practical',
          studentStrength: 65,
          department: 'Computer Science & Engineering',
          day: 'Monday',
          timeSlot: '10:45 - 12:15',
          assignedRoomId: 'room-lab-204', // Capacity 60! Over capacity by 5!
          assignedFacultyId: 'fac-alan-vance',
          requiredEquipment: [{ name: 'computers', minQuantity: 65 }],
          status: 'conflict_flagged',
          notes: '65 enrolled students assigned to Lab 204 (holds only 60).',
        },
        ...existing,
      ];
    });

    showToast(
      'Loaded Prompt Sample Scenario: Data Structures (65 students) assigned to Lab 204 (Capacity 60, 60 PCs). Capacity mismatch flagged!',
      'warning'
    );
  };

  const handleTriggerRoomMaintenance = () => {
    handleUpdateRoomStatus(
      'room-lab-204',
      'maintenance',
      'Emergency HVAC electrical repair and refrigerant leak'
    );
  };

  const handleTriggerFacultyAbsence = () => {
    handleUpdateFacultyStatus(
      'fac-alan-vance',
      'emergency_absent',
      'Medical emergency sick leave'
    );
  };

  const handleTriggerStudentSurge = () => {
    setAllocations((prev) =>
      prev.map((a) => {
        if (a.courseCode === 'CS405') {
          return {
            ...a,
            studentStrength: 78, // CR-205 capacity is 65
            notes: 'Enrollment surged from 52 to 78 students!',
          };
        }
        return a;
      })
    );
    showToast('Student Strength Surge applied: CS405 enrollment increased to 78 students.', 'warning');
  };

  const handleResetToCleanState = () => {
    setRooms(INITIAL_ROOMS);
    setFacultyList(INITIAL_FACULTY);
    setEquipmentList(INITIAL_EQUIPMENT);

    // Reallocate Data Structures to Lab 301 clean
    const cleanAllocations = INITIAL_ALLOCATIONS.map((a) => {
      if (a.id === 'alloc-ds-lab-sample') {
        return {
          ...a,
          assignedRoomId: 'room-lab-301', // Lab 301 has 75 capacity & 75 PCs!
          status: 'reallocated' as const,
          notes: 'Reallocated to Lab 301 HPC Center (Capacity 75, 75 PCs). Perfectly clash-free.',
        };
      }
      return { ...a, status: 'confirmed' as const };
    });

    setAllocations(cleanAllocations);
    showToast('Campus reset to clean state: Data Structures allocated to Lab 301 (75 seats). Zero conflicts.', 'success');
  };

  // --- Allocation Modal Handlers ---
  const handleSaveAllocation = (newAlloc: Allocation) => {
    setAllocations((prev) => {
      const exists = prev.some((a) => a.id === newAlloc.id);
      if (exists) {
        return prev.map((a) => (a.id === newAlloc.id ? newAlloc : a));
      }
      return [newAlloc, ...prev];
    });

    showToast(`Saved schedule for ${newAlloc.courseTitle} (${newAlloc.courseCode}).`, 'success');
  };

  const handleDeleteAllocation = (allocId: string) => {
    setAllocations((prev) => prev.filter((a) => a.id !== allocId));
    showToast('Allocation removed from timetable.', 'info');
  };

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-900 flex flex-col font-sans selection:bg-indigo-100 selection:text-indigo-900">
      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 animate-in fade-in slide-in-from-bottom-3 duration-300 max-w-md">
          <div
            className={`p-3.5 rounded-xl shadow-lg border flex items-center gap-3 text-xs font-medium ${
              toastMessage.type === 'success'
                ? 'bg-emerald-900 text-emerald-100 border-emerald-700'
                : toastMessage.type === 'warning'
                ? 'bg-amber-900 text-amber-100 border-amber-700'
                : 'bg-slate-900 text-slate-100 border-slate-700'
            }`}
          >
            {toastMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0" />
            )}
            <span className="flex-1">{toastMessage.text}</span>
            <button
              onClick={() => setToastMessage(null)}
              className="text-slate-400 hover:text-white cursor-pointer"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Global Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        criticalConflictCount={campusMetrics.criticalConflictsCount}
        warningsCount={campusMetrics.warningsCount}
        onOpenNewAllocation={() => {
          setAllocationToEdit(null);
          setInitialSlotForNew(null);
          setIsAllocationModalOpen(true);
        }}
        onOpenEmergencySimulator={() => setIsEmergencyModalOpen(true)}
        onOpenAIAssistant={() => setIsAIDrawerOpen(true)}
        onOpenHistory={() => setIsHistoryModalOpen(true)}
        onAutoResolveAll={handleAutoResolveAll}
      />

      {/* Main Content View */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-5 space-y-5">
        {/* Metric Cards Banner (Always visible for quick pulse) */}
        <MetricCards
          metrics={campusMetrics}
          onViewConflicts={() => setActiveTab('conflicts')}
        />

        {/* Prominent Conflict Alert Banner (Features Data Structures 65 vs 60 demo) */}
        <ConflictAlertBanner
          conflicts={activeConflicts}
          allocations={allocations}
          rooms={rooms}
          onApplyAlternative={handleApplyAlternative}
          onViewAllConflicts={() => setActiveTab('conflicts')}
        />

        {/* Tab 1: Dashboard Overview */}
        {activeTab === 'overview' && (
          <div className="space-y-5">
            {/* Quick Demo Prompt Banner */}
            <div className="bg-gradient-to-r from-indigo-900 to-slate-900 text-white rounded-xl p-4 sm:p-5 shadow-sm border border-indigo-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-indigo-500 text-white">
                    Interactive Demonstration
                  </span>
                  <h3 className="text-sm font-bold text-white">
                    Smart Campus Resource Management Scenario
                  </h3>
                </div>
                <p className="text-xs text-indigo-200 max-w-2xl">
                  <strong>Class:</strong> Data Structures (65 Students) • <strong>Required Resource:</strong> Computer Laboratory (65 Computers) • <strong>Initial Lab:</strong> Lab 204 (Capacity 60). The assistant detects the 5-seat deficit and recommends <strong>Lab 301 (Capacity 75, 75 PCs)</strong>.
                </p>
              </div>

              <div className="flex items-center gap-2 flex-shrink-0">
                <button
                  onClick={handleTriggerPromptSampleScenario}
                  className="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-indigo-500 hover:bg-indigo-400 text-white shadow-xs cursor-pointer transition-colors"
                >
                  Load Demo Conflict
                </button>
                <button
                  onClick={() => setIsEmergencyModalOpen(true)}
                  className="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 cursor-pointer transition-colors"
                >
                  More Scenarios
                </button>
              </div>
            </div>

            {/* Schedule Timetable in Overview */}
            <ScheduleTimetable
              allocations={allocations}
              rooms={rooms}
              facultyList={facultyList}
              conflicts={activeConflicts}
              onSelectAllocation={(alloc) => {
                setAllocationToEdit(alloc);
                setIsAllocationModalOpen(true);
              }}
              onEditAllocation={(alloc) => {
                setAllocationToEdit(alloc);
                setIsAllocationModalOpen(true);
              }}
              onNewAllocationForSlot={(day, slot) => {
                setAllocationToEdit(null);
                setInitialSlotForNew({ day, slot });
                setIsAllocationModalOpen(true);
              }}
              onResolveConflictForAllocation={(alloc) => {
                setActiveTab('conflicts');
              }}
            />
          </div>
        )}

        {/* Tab 2: Timetable & Schedule Grid */}
        {activeTab === 'schedule' && (
          <ScheduleTimetable
            allocations={allocations}
            rooms={rooms}
            facultyList={facultyList}
            conflicts={activeConflicts}
            onSelectAllocation={(alloc) => {
              setAllocationToEdit(alloc);
              setIsAllocationModalOpen(true);
            }}
            onEditAllocation={(alloc) => {
              setAllocationToEdit(alloc);
              setIsAllocationModalOpen(true);
            }}
            onNewAllocationForSlot={(day, slot) => {
              setAllocationToEdit(null);
              setInitialSlotForNew({ day, slot });
              setIsAllocationModalOpen(true);
            }}
            onResolveConflictForAllocation={() => {
              setActiveTab('conflicts');
            }}
          />
        )}

        {/* Tab 3: Conflict Workbench & Smart Reallocation */}
        {activeTab === 'conflicts' && (
          <ConflictReallocationCenter
            conflicts={activeConflicts}
            allocations={allocations}
            rooms={rooms}
            facultyList={facultyList}
            onApplyAlternative={handleApplyAlternative}
            onAutoResolveAll={handleAutoResolveAll}
            onOpenNewAllocation={() => {
              setAllocationToEdit(null);
              setInitialSlotForNew(null);
              setIsAllocationModalOpen(true);
            }}
          />
        )}

        {/* Tab 4: Resource Directory */}
        {activeTab === 'resources' && (
          <ResourceDirectory
            rooms={rooms}
            facultyList={facultyList}
            equipmentList={equipmentList}
            onUpdateRoomStatus={handleUpdateRoomStatus}
            onUpdateFacultyStatus={handleUpdateFacultyStatus}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-200 bg-white py-4 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p>
            Smart Campus Resource Management Assistant • Designed for Higher Education Institutions
          </p>
          <div className="flex items-center gap-3 text-slate-400">
            <span>Capacity Constraint Solver</span>
            <span>•</span>
            <span>Real-time Anti-Clash Verification</span>
            <span>•</span>
            <span>Zero Data Loss</span>
          </div>
        </div>
      </footer>

      {/* Modals & Drawers */}
      <AllocationModal
        isOpen={isAllocationModalOpen}
        onClose={() => {
          setIsAllocationModalOpen(false);
          setAllocationToEdit(null);
          setInitialSlotForNew(null);
        }}
        allocationToEdit={allocationToEdit}
        initialDay={initialSlotForNew?.day}
        initialTimeSlot={initialSlotForNew?.slot}
        allAllocations={allocations}
        rooms={rooms}
        facultyList={facultyList}
        onSave={handleSaveAllocation}
        onDelete={handleDeleteAllocation}
      />

      <EmergencySimulatorModal
        isOpen={isEmergencyModalOpen}
        onClose={() => setIsEmergencyModalOpen(false)}
        onTriggerPromptSampleScenario={handleTriggerPromptSampleScenario}
        onTriggerRoomMaintenance={handleTriggerRoomMaintenance}
        onTriggerFacultyAbsence={handleTriggerFacultyAbsence}
        onTriggerStudentSurge={handleTriggerStudentSurge}
        onResetToCleanState={handleResetToCleanState}
      />

      <ReallocationHistoryModal
        isOpen={isHistoryModalOpen}
        onClose={() => setIsHistoryModalOpen(false)}
        logs={reallocationLogs}
        onClearLogs={() => {
          setReallocationLogs([]);
          showToast('Audit trail history cleared.', 'info');
        }}
      />

      <AIAssistantDrawer
        isOpen={isAIDrawerOpen}
        onClose={() => setIsAIDrawerOpen(false)}
        allocations={allocations}
        rooms={rooms}
        facultyList={facultyList}
        conflicts={activeConflicts}
      />
    </div>
  );
}
